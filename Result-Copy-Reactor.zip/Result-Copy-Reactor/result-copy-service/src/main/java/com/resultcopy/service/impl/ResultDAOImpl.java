package com.resultcopy.service.impl;

import com.resultcopy.CategoryDto;
import com.resultcopy.ChildResultDto;
import com.resultcopy.PatientResultDto;
import com.resultcopy.ResultDto;
import com.resultcopy.service.ConnectionFactory;
import com.resultcopy.service.dao.PatientDAO;
import com.resultcopy.service.dao.ResultDAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ResultDAOImpl implements ResultDAO {
    public List<ResultDto> getCategories(Integer categoryId){
        PatientDAO patientDao=new PatientDAOImpl();
        ResultDto result=null;
        CategoryDto category=null;
        List<ResultDto> resultList=new ArrayList<>();
        Connection con = ConnectionFactory.getConnection();
        String sql = "SELECT rs.result_id,rs.result_name from result rs,category c where rs.category_id=c.category_id and c.category_id="+categoryId;
        System.out.println("Choti Wali Query SQL : "+sql);
        try{
            PreparedStatement pStmt = con.prepareStatement(sql);
            ResultSet rs = pStmt.executeQuery();

            while (rs.next()) {
                result=new ResultDto();
                result.setId(rs.getInt("RESULT_ID"));
                result.setDisplayName(rs.getString("RESULT_NAME"));
                resultList.add(result);

            }
            category = new CategoryDto();
            category.setResult(resultList);
        }catch (SQLException ex){
            ex.printStackTrace();
        }

        category.setResult(resultList);
        return resultList;
    }

    @Override
    public List<ChildResultDto> getChildValueById(Integer patientId) {

        List<ChildResultDto> resultList=new ArrayList<>();
        Connection con = ConnectionFactory.getConnection();
        String sql = "select  pr.CHILD_ID,pr.value,rs.RESULT_ID from patient p,result rs ," +
                     "patient_result pr,result_details rd,category c, child ch " +
                      "where p.patient_ID=pr.patient_Id and " +
                      "pr.patient_result_ID=rd.Patient_result_ID and " +
                      "rd.result_ID=rs.result_ID and "+
                      "rs.category_ID=c.category_ID and " +
                      "p.patient_ID=ch.patient_ID and " +
                      "p.patient_ID= "+patientId;

        try{
            PreparedStatement pStmt = con.prepareStatement(sql);
            ResultSet rs = pStmt.executeQuery();
            ChildResultDto patientResult = null;
            while (rs.next()) {
                patientResult=new ChildResultDto();
                patientResult.setChildId(rs.getInt("CHILD_ID"));
                patientResult.setResultId(rs.getInt("RESULT_ID"));
                patientResult.setValue(rs.getString("VALUE"));

                resultList.add(patientResult);

            }

        }catch (SQLException ex){
            ex.printStackTrace();
        }

        return resultList;
    }
}
