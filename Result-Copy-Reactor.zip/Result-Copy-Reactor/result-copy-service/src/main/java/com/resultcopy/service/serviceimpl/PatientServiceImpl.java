package com.resultcopy.service.serviceimpl;

import com.resultcopy.*;
import com.resultcopy.service.dao.*;
import com.resultcopy.service.impl.*;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class PatientServiceImpl {

    PatientDAO dao = new PatientDAOImpl();
    ChildDAO childDAO = new ChildDAOImpl() ;
    ResultDAO resultDAO = new ResultDAOImpl();

    public PatientResultDto getPatientDetails(String patientId){
        PatientResultDto patient = new PatientResultDto();
        List<CategoryDto> categoryDtoList = new ArrayList<>();
        PatientDto p =dao.getPatientById(Integer.parseInt(patientId));

        List<PatientDetailsDto> patientDetailsList = childDAO.getPatientById(Integer.parseInt(patientId));
        List<ChildDto> childDtoList = new ArrayList<>();

        ChildDto childDto = new ChildDto();
        childDto.setChildDetails(patientDetailsList);
        childDtoList.add(childDto);

        PatientDto childDetails  = null;
        CategoryDAO categoryDAO=new CategoryDAOImpl();
        List<CategoryDto> categoryList = categoryDAO.getCategories();
        BabyResultDAO babyResultDAO = new BabyResultDAOImpl();
        for(PatientDetailsDto patientDetail:patientDetailsList) {
            BabyResultDto br = babyResultDAO.getBabyPatientByChildId(patientDetail.getId());
            if(null!=br){
                patientDetail.setResultCopiedDateTime(br.getDateTime());
            }else {
                patient.setCategory(categoryList);
                for(CategoryDto category:categoryList) {
                    List<ChildResultDto> childResultsList =resultDAO.getChildValueById(Integer.parseInt(patientId));
                    List<ResultDto> resultList = resultDAO.getCategories(category.getId());
                    //ChildResultDto childResultDto = null;
                    ResultDto resultDto=null;
                    List<ChildResultDto> childResultDtoList = new ArrayList<>();
                    for (ChildResultDto pr : childResultsList) {
                        resultDto = new ResultDto();
                        for(ResultDto result :resultList) {
                            if (result.getId() == pr.getResultId()) {
                                 //childResultDto = new ChildResultDto();
                                // childResultDto.setChildId(pr.getChildId());
                               // childResultDto.setValue(pr.getValue());
                               // childResultDtoList.add(childResultDto);
                                result.setValue(pr.getValue());
                                //result.setChildResult(childResultDtoList);
                            }
                        }
                    }
                    resultList.add(resultDto);
                    category.setResult(resultList);
                 }
                }
            }
        patient.setPatient(p);
        patient.setChild(childDtoList);
        return patient;
    }
}
