package com.resultcopy.service.dao;

import com.resultcopy.ChildResultDto;
import com.resultcopy.PatientResultDto;
import com.resultcopy.ResultDto;

import java.util.List;

public interface ResultDAO {

    public List<ResultDto> getCategories(Integer categoryId);
    //my exp
    public List<ChildResultDto> getChildValueById(Integer patientId);

}
