package com.resultcopy;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class ResultDto implements Serializable {
    private Integer id ;
    private String displayName ;
    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    private String value;
    private List<ChildResultDto> childResult = new ArrayList<>();

}
